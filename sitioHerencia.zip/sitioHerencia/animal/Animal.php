<?php
    abstract class Animal{

        var $name = "Animal";

        public function comer(){
            echo "<p>".$this->name." comiendo</p>";
        }

        protected function dormir(){
            echo "<p>".$this->name." durmiendo</p>";
        }

        
    }