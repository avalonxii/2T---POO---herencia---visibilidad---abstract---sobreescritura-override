<?php
    class Perro extends Animal{
        
        public function UsarProtected(){
            $this->dormir();
        }

        //sobreescritura de metodo comer de clase Animal
        public function comer(){
            echo "<p>Perro come huesos</p>";
        }

    }