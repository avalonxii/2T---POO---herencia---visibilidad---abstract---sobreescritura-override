<?php
    class Gato extends Animal{
        
        public function UsarProtected(){
            $this->dormir();
        }

    }