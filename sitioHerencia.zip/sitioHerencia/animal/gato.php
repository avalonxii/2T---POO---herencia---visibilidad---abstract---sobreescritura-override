<?php
    class Gato extends Animal{

        var $name = "Gato";
        
        public function UsarProtected(){
            $this->dormir();
        }

    }